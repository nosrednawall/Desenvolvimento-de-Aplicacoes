package calculadora.model;

public enum Operacoes {
	SOMA,SUBTRACAO,DIVISAO,MULTIPLICACAO,RESTO;	
}
